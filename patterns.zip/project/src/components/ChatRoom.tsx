import React, { useState, useEffect, useRef } from 'react';
import { Send, Users, LogOut } from 'lucide-react';
import { ChatService } from '../services/ChatService';
import { IMessage, IUser } from '../types/ChatTypes';

interface ChatRoomProps {
  roomId: string;
  username: string;
  onLeaveRoom: () => void;
}

export const ChatRoom: React.FC<ChatRoomProps> = ({ roomId, username, onLeaveRoom }) => {
  const [messages, setMessages] = useState<IMessage[]>([]);
  const [activeUsers, setActiveUsers] = useState<IUser[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const chatServiceRef = useRef<ChatService>();
  const currentUserRef = useRef<any>(null);

  useEffect(() => {
    // Initialize chat service
    chatServiceRef.current = new ChatService('websocket');
    
    try {
      // Join the room
      const result = chatServiceRef.current.joinRoom(roomId, username, (data: any) => {
        console.log('Chat data received:', data);
        
        switch (data.type) {
          case 'NEW_MESSAGE':
            setMessages(prev => [...prev, data.message]);
            break;
          case 'USER_JOINED':
            setActiveUsers(data.activeUsers);
            break;
          case 'USER_LEFT':
            setActiveUsers(data.activeUsers);
            break;
          case 'MESSAGE_HISTORY':
            if (data.userId === currentUserRef.current?.id) {
              setMessages(data.messages);
            }
            break;
          default:
            console.log('Unknown data type:', data.type);
        }
      });
      
      currentUserRef.current = result.user;
      setIsConnected(true);
      
      // Set initial active users
      const room = chatServiceRef.current.getRoom(roomId);
      if (room) {
        setActiveUsers(room.getActiveUsers());
        setMessages(room.getRecentMessages());
      }
      
    } catch (error) {
      console.error('Error joining room:', error);
      setIsConnected(false);
    }

    return () => {
      // Cleanup
      if (chatServiceRef.current && currentUserRef.current) {
        chatServiceRef.current.leaveRoom(roomId, currentUserRef.current.id);
      }
    };
  }, [roomId, username]);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !chatServiceRef.current || !currentUserRef.current) return;

    try {
      chatServiceRef.current.sendMessage(
        roomId,
        currentUserRef.current.id,
        username,
        newMessage.trim()
      );
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleLeaveRoom = () => {
    if (chatServiceRef.current && currentUserRef.current) {
      chatServiceRef.current.leaveRoom(roomId, currentUserRef.current.id);
    }
    onLeaveRoom();
  };

  const formatTime = (timestamp: Date) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-800">Room: {roomId}</h1>
            <p className="text-sm text-gray-600">
              Connected as: {username} 
              <span className={`ml-2 inline-block w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></span>
            </p>
          </div>
          <button
            onClick={handleLeaveRoom}
            className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
          >
            <LogOut size={16} />
            Leave Room
          </button>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <p>No messages yet. Start the conversation!</p>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.username === username ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    message.username === username
                      ? 'bg-blue-500 text-white'
                      : 'bg-white border border-gray-200 text-gray-800'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium opacity-75">
                      {message.username}
                    </span>
                    <span className="text-xs opacity-50">
                      {formatTime(message.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm">{message.content}</p>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <form onSubmit={handleSendMessage} className="bg-white border-t border-gray-200 p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              maxLength={500}
            />
            <button
              type="submit"
              disabled={!newMessage.trim() || !isConnected}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              <Send size={16} />
              Send
            </button>
          </div>
        </form>
      </div>

      {/* Sidebar - Active Users */}
      <div className="w-64 bg-white border-l border-gray-200 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Users size={18} />
          <h2 className="font-semibold text-gray-800">Active Users ({activeUsers.length})</h2>
        </div>
        <div className="space-y-2">
          {activeUsers.map((user) => (
            <div
              key={user.id}
              className="flex items-center gap-2 p-2 rounded-lg bg-gray-50"
            >
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm text-gray-700">
                {user.username}
                {user.username === username && (
                  <span className="text-xs text-blue-500 ml-1">(You)</span>
                )}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};