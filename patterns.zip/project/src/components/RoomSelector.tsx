import React, { useState } from 'react';
import { MessageCircle, Users, Plus } from 'lucide-react';

interface RoomSelectorProps {
  onJoinRoom: (roomId: string, username: string) => void;
}

export const RoomSelector: React.FC<RoomSelectorProps> = ({ onJoinRoom }) => {
  const [roomId, setRoomId] = useState('');
  const [username, setUsername] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  const popularRooms = [
    { id: 'general', name: 'General Discussion', users: 12 },
    { id: 'tech', name: 'Technology', users: 8 },
    { id: 'random', name: 'Random', users: 5 },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (roomId.trim() && username.trim()) {
      onJoinRoom(roomId.trim(), username.trim());
    }
  };

  const handleQuickJoin = (selectedRoomId: string) => {
    if (username.trim()) {
      onJoinRoom(selectedRoomId, username.trim());
    }
  };

  const generateRandomRoomId = () => {
    const adjectives = ['Cool', 'Fast', 'Smart', 'Epic', 'Super'];
    const nouns = ['Tigers', 'Eagles', 'Sharks', 'Lions', 'Hawks'];
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    const number = Math.floor(Math.random() * 1000);
    return `${adj}${noun}${number}`;
  };

  const handleCreateRoom = () => {
    const newRoomId = generateRandomRoomId();
    setRoomId(newRoomId);
    setIsCreating(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
            <MessageCircle size={32} className="text-blue-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Real-time Chat</h1>
          <p className="text-gray-600">Join a room or create your own</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
              Your Name
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
              maxLength={20}
            />
          </div>

          <div>
            <label htmlFor="roomId" className="block text-sm font-medium text-gray-700 mb-2">
              Room ID
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                id="roomId"
                value={roomId}
                onChange={(e) => setRoomId(e.target.value)}
                placeholder="Enter room ID"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
                maxLength={20}
              />
              <button
                type="button"
                onClick={handleCreateRoom}
                className="px-3 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors"
                title="Generate random room ID"
              >
                <Plus size={20} />
              </button>
            </div>
            {isCreating && (
              <p className="text-xs text-blue-600 mt-1">Random room ID generated!</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium"
          >
            Join Room
          </button>
        </form>

        {username.trim() && (
          <>
            <div className="my-6 flex items-center">
              <div className="flex-1 border-t border-gray-300"></div>
              <span className="px-3 text-sm text-gray-500">or join popular rooms</span>
              <div className="flex-1 border-t border-gray-300"></div>
            </div>

            <div className="space-y-2">
              {popularRooms.map((room) => (
                <button
                  key={room.id}
                  onClick={() => handleQuickJoin(room.id)}
                  className="w-full p-3 text-left bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors border border-gray-200"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">{room.name}</p>
                      <p className="text-xs text-gray-500">Room ID: {room.id}</p>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Users size={12} />
                      {room.users}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </>
        )}

        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Built with TypeScript • Observer Pattern • Singleton Pattern • Adapter Pattern</p>
        </div>
      </div>
    </div>
  );
};