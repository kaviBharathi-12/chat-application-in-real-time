// Core types for the chat application
export interface IMessage {
  id: string;
  userId: string;
  username: string;
  content: string;
  timestamp: Date;
  roomId: string;
}

export interface IUser {
  id: string;
  username: string;
  isActive: boolean;
  joinedAt: Date;
}

export interface IChatRoom {
  id: string;
  name: string;
  users: Map<string, IUser>;
  messages: IMessage[];
  createdAt: Date;
}

export interface IObserver {
  update(data: any): void;
}

export interface ICommunicationAdapter {
  connect(url: string): void;
  disconnect(): void;
  sendMessage(message: any): void;
  onMessage(callback: (message: any) => void): void;
  onConnect(callback: () => void): void;
  onDisconnect(callback: () => void): void;
}