import { IMessage } from '../types/ChatTypes';

export class Message implements IMessage {
  public readonly id: string;
  public readonly userId: string;
  public readonly username: string;
  public readonly content: string;
  public readonly timestamp: Date;
  public readonly roomId: string;

  constructor(userId: string, username: string, content: string, roomId: string) {
    this.id = this.generateId();
    this.userId = userId;
    this.username = username;
    this.content = this.sanitizeContent(content);
    this.timestamp = new Date();
    this.roomId = roomId;
  }

  private generateId(): string {
    return `msg_${Math.random().toString(36).substr(2, 9)}_${Date.now()}`;
  }

  private sanitizeContent(content: string): string {
    // Basic content sanitization
    return content.trim().substring(0, 500);
  }

  toJSON(): IMessage {
    return {
      id: this.id,
      userId: this.userId,
      username: this.username,
      content: this.content,
      timestamp: this.timestamp,
      roomId: this.roomId
    };
  }
}