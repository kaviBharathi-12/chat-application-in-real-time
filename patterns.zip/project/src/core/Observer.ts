import { IObserver } from '../types/ChatTypes';

// Observer Pattern Implementation
export abstract class Observable {
  private observers: IObserver[] = [];

  addObserver(observer: IObserver): void {
    if (!this.observers.includes(observer)) {
      this.observers.push(observer);
      console.log(`Observer added. Total observers: ${this.observers.length}`);
    }
  }

  removeObserver(observer: IObserver): void {
    const index = this.observers.indexOf(observer);
    if (index > -1) {
      this.observers.splice(index, 1);
      console.log(`Observer removed. Total observers: ${this.observers.length}`);
    }
  }

  protected notifyObservers(data: any): void {
    console.log(`Notifying ${this.observers.length} observers with data:`, data);
    this.observers.forEach(observer => {
      try {
        observer.update(data);
      } catch (error) {
        console.error('Error notifying observer:', error);
      }
    });
  }
}

export class ChatObserver implements IObserver {
  private callback: (data: any) => void;

  constructor(callback: (data: any) => void) {
    this.callback = callback;
  }

  update(data: any): void {
    this.callback(data);
  }
}

export { Observable }