import { Observable } from './Observer';
import { User } from './User';
import { Message } from './Message';
import { IChatRoom, IUser, IMessage } from '../types/ChatTypes';

export class ChatRoom extends Observable implements IChatRoom {
  public readonly id: string;
  public readonly name: string;
  public readonly users: Map<string, IUser>;
  public readonly messages: IMessage[];
  public readonly createdAt: Date;
  private messageHistory: Map<string, IMessage[]>;

  constructor(id: string, name?: string) {
    super();
    this.id = id;
    this.name = name || `Room ${id}`;
    this.users = new Map();
    this.messages = [];
    this.messageHistory = new Map();
    this.createdAt = new Date();
    console.log(`ChatRoom created: ${this.name} (${this.id})`);
  }

  addUser(user: User): void {
    try {
      if (this.users.has(user.id)) {
        console.log(`User ${user.username} is already in room ${this.name}`);
        return;
      }

      this.users.set(user.id, user.toJSON());
      console.log(`User ${user.username} joined room ${this.name}`);
      
      // Notify observers about user joining
      this.notifyObservers({
        type: 'USER_JOINED',
        user: user.toJSON(),
        roomId: this.id,
        activeUsers: Array.from(this.users.values())
      });

      // Send message history to new user
      const history = this.messageHistory.get(this.id) || [];
      if (history.length > 0) {
        this.notifyObservers({
          type: 'MESSAGE_HISTORY',
          messages: history,
          userId: user.id
        });
      }
    } catch (error) {
      console.error('Error adding user to chat room:', error);
    }
  }

  removeUser(userId: string): void {
    try {
      const user = this.users.get(userId);
      if (user) {
        this.users.delete(userId);
        console.log(`User ${user.username} left room ${this.name}`);
        
        this.notifyObservers({
          type: 'USER_LEFT',
          user,
          roomId: this.id,
          activeUsers: Array.from(this.users.values())
        });
      }
    } catch (error) {
      console.error('Error removing user from chat room:', error);
    }
  }

  addMessage(userId: string, username: string, content: string): void {
    try {
      if (!this.users.has(userId)) {
        throw new Error('User not in room');
      }

      const message = new Message(userId, username, content, this.id);
      this.messages.push(message.toJSON());
      
      // Store in message history
      if (!this.messageHistory.has(this.id)) {
        this.messageHistory.set(this.id, []);
      }
      const history = this.messageHistory.get(this.id)!;
      history.push(message.toJSON());
      
      // Keep only last 100 messages in history
      if (history.length > 100) {
        history.shift();
      }

      console.log(`Message sent in room ${this.name}: [${username}] ${content}`);
      
      this.notifyObservers({
        type: 'NEW_MESSAGE',
        message: message.toJSON(),
        roomId: this.id
      });
    } catch (error) {
      console.error('Error adding message:', error);
    }
  }

  getActiveUsers(): IUser[] {
    return Array.from(this.users.values()).filter(user => user.isActive);
  }

  getRecentMessages(limit: number = 50): IMessage[] {
    return this.messages.slice(-limit);
  }
}