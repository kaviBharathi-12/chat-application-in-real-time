import { IUser } from '../types/ChatTypes';

export class User implements IUser {
  public readonly id: string;
  public readonly username: string;
  public isActive: boolean;
  public readonly joinedAt: Date;

  constructor(username: string) {
    this.id = this.generateId();
    this.username = username;
    this.isActive = true;
    this.joinedAt = new Date();
  }

  private generateId(): string {
    return `user_${Math.random().toString(36).substr(2, 9)}_${Date.now()}`;
  }

  setActive(active: boolean): void {
    this.isActive = active;
    console.log(`User ${this.username} is now ${active ? 'active' : 'inactive'}`);
  }

  toJSON(): IUser {
    return {
      id: this.id,
      username: this.username,
      isActive: this.isActive,
      joinedAt: this.joinedAt
    };
  }
}