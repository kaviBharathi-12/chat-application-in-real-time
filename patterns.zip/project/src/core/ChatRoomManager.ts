import { ChatRoom } from './ChatRoom';
import { User } from './User';
import { IChatRoom } from '../types/ChatTypes';

// Singleton Pattern Implementation
export class ChatRoomManager {
  private static instance: ChatRoomManager;
  private rooms: Map<string, ChatRoom>;
  private users: Map<string, User>;

  private constructor() {
    this.rooms = new Map();
    this.users = new Map();
    console.log('ChatRoomManager initialized (Singleton)');
  }

  public static getInstance(): ChatRoomManager {
    if (!ChatRoomManager.instance) {
      ChatRoomManager.instance = new ChatRoomManager();
    }
    return ChatRoomManager.instance;
  }

  createRoom(roomId: string, roomName?: string): ChatRoom {
    try {
      if (this.rooms.has(roomId)) {
        console.log(`Room ${roomId} already exists`);
        return this.rooms.get(roomId)!;
      }

      const room = new ChatRoom(roomId, roomName);
      this.rooms.set(roomId, room);
      console.log(`Room created: ${roomId}`);
      return room;
    } catch (error) {
      console.error('Error creating room:', error);
      throw error;
    }
  }

  joinRoom(roomId: string, username: string): { room: ChatRoom; user: User } {
    try {
      let room = this.rooms.get(roomId);
      if (!room) {
        room = this.createRoom(roomId);
      }

      let user = Array.from(this.users.values()).find(u => u.username === username);
      if (!user) {
        user = new User(username);
        this.users.set(user.id, user);
      }

      room.addUser(user);
      return { room, user };
    } catch (error) {
      console.error('Error joining room:', error);
      throw error;
    }
  }

  leaveRoom(roomId: string, userId: string): void {
    try {
      const room = this.rooms.get(roomId);
      if (room) {
        room.removeUser(userId);
        
        // Remove room if empty
        if (room.users.size === 0) {
          this.rooms.delete(roomId);
          console.log(`Empty room ${roomId} removed`);
        }
      }
    } catch (error) {
      console.error('Error leaving room:', error);
    }
  }

  getRoom(roomId: string): ChatRoom | undefined {
    return this.rooms.get(roomId);
  }

  getAllRooms(): IChatRoom[] {
    return Array.from(this.rooms.values()).map(room => ({
      id: room.id,
      name: room.name,
      users: room.users,
      messages: room.messages,
      createdAt: room.createdAt
    }));
  }
}