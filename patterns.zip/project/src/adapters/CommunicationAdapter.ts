import { ICommunicationAdapter } from '../types/ChatTypes';

// Adapter Pattern Implementation - Base Adapter
export abstract class CommunicationAdapter implements ICommunicationAdapter {
  protected isConnected: boolean = false;
  protected messageCallback?: (message: any) => void;
  protected connectCallback?: () => void;
  protected disconnectCallback?: () => void;

  abstract connect(url: string): void;
  abstract disconnect(): void;
  abstract sendMessage(message: any): void;

  onMessage(callback: (message: any) => void): void {
    this.messageCallback = callback;
  }

  onConnect(callback: () => void): void {
    this.connectCallback = callback;
  }

  onDisconnect(callback: () => void): void {
    this.disconnectCallback = callback;
  }

  protected handleMessage(message: any): void {
    if (this.messageCallback) {
      this.messageCallback(message);
    }
  }

  protected handleConnect(): void {
    this.isConnected = true;
    console.log('Communication adapter connected');
    if (this.connectCallback) {
      this.connectCallback();
    }
  }

  protected handleDisconnect(): void {
    this.isConnected = false;
    console.log('Communication adapter disconnected');
    if (this.disconnectCallback) {
      this.disconnectCallback();
    }
  }
}

// WebSocket Adapter Implementation
export class WebSocketAdapter extends CommunicationAdapter {
  private socket?: WebSocket;

  connect(url: string): void {
    try {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        console.log('WebSocket already connected');
        return;
      }

      this.socket = new WebSocket(url);
      
      this.socket.onopen = () => {
        this.handleConnect();
      };

      this.socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      this.socket.onclose = () => {
        this.handleDisconnect();
      };

      this.socket.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
    } catch (error) {
      console.error('Error connecting WebSocket:', error);
    }
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.close();
      this.socket = undefined;
    }
  }

  sendMessage(message: any): void {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(message));
    } else {
      console.error('WebSocket not connected');
    }
  }
}

// Mock HTTP Adapter (for demonstration of Adapter Pattern)
export class HTTPAdapter extends CommunicationAdapter {
  private pollInterval?: NodeJS.Timeout;
  private url: string = '';

  connect(url: string): void {
    this.url = url;
    console.log('HTTP Adapter connected (polling mode)');
    this.handleConnect();
    
    // Simulate polling for messages
    this.pollInterval = setInterval(() => {
      // In a real implementation, this would make HTTP requests
      console.log('Polling for messages...');
    }, 3000);
  }

  disconnect(): void {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = undefined;
    }
    this.handleDisconnect();
  }

  sendMessage(message: any): void {
    // In a real implementation, this would make an HTTP POST request
    console.log('Sending message via HTTP:', message);
    
    // Simulate message echo for demo
    setTimeout(() => {
      this.handleMessage({
        type: 'MESSAGE_SENT',
        success: true
      });
    }, 100);
  }
}

export { CommunicationAdapter }