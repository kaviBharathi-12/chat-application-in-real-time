import React, { useState } from 'react';
import { RoomSelector } from './components/RoomSelector';
import { ChatRoom } from './components/ChatRoom';

interface AppState {
  currentRoom?: string;
  currentUsername?: string;
}

function App() {
  const [appState, setAppState] = useState<AppState>({});

  const handleJoinRoom = (roomId: string, username: string) => {
    console.log(`Joining room: ${roomId} as ${username}`);
    setAppState({
      currentRoom: roomId,
      currentUsername: username
    });
  };

  const handleLeaveRoom = () => {
    console.log('Leaving room');
    setAppState({});
  };

  return (
    <div className="App">
      {!appState.currentRoom ? (
        <RoomSelector onJoinRoom={handleJoinRoom} />
      ) : (
        <ChatRoom
          roomId={appState.currentRoom}
          username={appState.currentUsername!}
          onLeaveRoom={handleLeaveRoom}
        />
      )}
    </div>
  );
}

export default App;