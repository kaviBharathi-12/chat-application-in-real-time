import { ChatRoomManager } from '../core/ChatRoomManager';
import { ChatObserver } from '../core/Observer';
import { CommunicationAdapter, WebSocketAdapter, HTTPAdapter } from '../adapters/CommunicationAdapter';

export class ChatService {
  private chatManager: ChatRoomManager;
  private communicationAdapter: CommunicationAdapter;
  private observer?: ChatObserver;

  constructor(adapterType: 'websocket' | 'http' = 'websocket') {
    this.chatManager = ChatRoomManager.getInstance();
    
    // Use Adapter Pattern to support different communication protocols
    switch (adapterType) {
      case 'websocket':
        this.communicationAdapter = new WebSocketAdapter();
        break;
      case 'http':
        this.communicationAdapter = new HTTPAdapter();
        break;
      default:
        this.communicationAdapter = new WebSocketAdapter();
    }

    console.log(`ChatService initialized with ${adapterType} adapter`);
  }

  setupObserver(callback: (data: any) => void): void {
    this.observer = new ChatObserver(callback);
    console.log('Chat observer setup completed');
  }

  joinRoom(roomId: string, username: string, callback: (data: any) => void): void {
    try {
      const { room, user } = this.chatManager.joinRoom(roomId, username);
      
      if (this.observer) {
        room.addObserver(this.observer);
      }

      // Setup new observer for this specific interaction
      const roomObserver = new ChatObserver(callback);
      room.addObserver(roomObserver);

      return { room, user };
    } catch (error) {
      console.error('Error joining room via service:', error);
      throw error;
    }
  }

  leaveRoom(roomId: string, userId: string): void {
    try {
      this.chatManager.leaveRoom(roomId, userId);
    } catch (error) {
      console.error('Error leaving room via service:', error);
    }
  }

  sendMessage(roomId: string, userId: string, username: string, content: string): void {
    try {
      const room = this.chatManager.getRoom(roomId);
      if (room) {
        room.addMessage(userId, username, content);
        
        // Also send via communication adapter
        this.communicationAdapter.sendMessage({
          type: 'CHAT_MESSAGE',
          roomId,
          userId,
          username,
          content,
          timestamp: new Date()
        });
      }
    } catch (error) {
      console.error('Error sending message via service:', error);
    }
  }

  getRoom(roomId: string) {
    return this.chatManager.getRoom(roomId);
  }
}